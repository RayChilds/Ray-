

```python
import numpy as np
```


```python
import matplotlib.pyplot as plt 
```


```python
%matplotlib inline
```


```python
bernoulli = np.random.binomial(1,.5, 100)
```


```python
plt.hist(bernoulli)
plt.axvline(bernoulli.mean(), color='b', linestyle='solid', linewidth=2)
plt.axvline(bernoulli.mean() + bernoulli.std(), color='b', linestyle='dashed', linewidth=2)
plt.axvline(bernoulli.mean()-bernoulli.std(), color='b', linestyle='dashed', linewidth=2) 
plt.show()
```


![png](output_4_0.png)



```python
np.mean(bernoulli)
```




    0.46000000000000002




```python
np.std(bernoulli)
```




    0.49839743177508444




```python
#Helpful to understand two possible outcomes of an event. 
```


```python
binomial = np.random.binomial(20, 0.5, 100)
```


```python
plt.hist(binomial)
plt.axvline(binomial.mean(), color='b', linestyle='solid', linewidth=2)
plt.axvline(binomial.mean() + binomial.std(), color='b', linestyle='dashed', linewidth=2)
plt.axvline(binomial.mean()-binomial.std(), color='b', linestyle='dashed', linewidth=2) 
plt.show()
```


![png](output_9_0.png)



```python
np.mean(binomial)
```




    9.7300000000000004




```python
np.std(binomial)
```




    2.5068705590835756




```python
#Helpful to count the number of successes when an event with two possible outcomes is repeated many times. 
```


```python
gamma = np.random.gamma(5, 1, 100)
```


```python
plt.hist(gamma)
plt.axvline(gamma.mean(), color='b', linestyle='solid', linewidth=2)
plt.axvline(gamma.mean() + gamma.std(), color='b', linestyle='dashed', linewidth=2)
plt.axvline(gamma.mean()-gamma.std(), color='b', linestyle='dashed', linewidth=2) 
plt.show()
```


![png](output_14_0.png)



```python
np.mean(gamma)
```




    4.6529772514281627




```python
np.std(gamma)
```




    1.8747950785966303




```python
#Represents the time unti an event (when event starts out unlikely), becomes more likely, then becomes more likely again, 
#and less likely afterward. 
```


```python
poisson = np.random.poisson(3, 100)
```


```python
plt.hist(poisson)
plt.axvline(poisson.mean(), color='b', linestyle='solid', linewidth=2)
plt.axvline(poisson.mean() + poisson.std(), color='b', linestyle='dashed', linewidth=2)
plt.axvline(poisson.mean()-poisson.std(), color='b', linestyle='dashed', linewidth=2) 
plt.show()
```


![png](output_19_0.png)



```python
np.mean(poisson)
```




    2.8100000000000001




```python
np.std(poisson)
```




    1.481181960462657




```python
#Represents the amount of time an event happens in a particular interval of time. 
```


```python
beta = np.random.beta(5, 1, 100)
plt.hist(beta)
plt.axvline(beta.mean(), color='b', linestyle='solid', linewidth=2)
plt.axvline(beta.mean() + beta.std(), color='b', linestyle='dashed', linewidth=2)
plt.axvline(beta.mean()-beta.std(), color='b', linestyle='dashed', linewidth=2) 
plt.show()
```


![png](output_23_0.png)



```python
np.mean(beta)
```




    0.80869374128554283




```python
np.std(beta)
```




    0.16640313442227234




```python
#To model the behavior of random variables limited to intervals of finite length in a wide variety of disciplines.
```


```python
negative_binomial = np.random.negative_binomial(5, 1, 100)
```


```python
plt.hist(negative_binomial)
plt.axvline(negative_binomial.mean(), color='b', linestyle='solid', linewidth=2)
plt.axvline(negative_binomial.mean() + negative_binomial.std(), color='b', linestyle='dashed', linewidth=2)
plt.axvline(negative_binomial.mean()-negative_binomial.std(), color='b', linestyle='dashed', linewidth=2) 
plt.show()
```


![png](output_28_0.png)



```python
np.mean(negative_binomial)
```




    0.0




```python
np.std(negative_binomial)
```




    0.0




```python
#Frequency distribution of the possible number of successful outcomes in a given number of trials in each of which
#there is the same probaility of success. 
```


```python
#The skewed distributions have means and standard deviations further away from each other; whilst the "normal" distributions
#have a central tendency. But these other distributions are still useful with large amounts of data and serve their 
#specific purposes. #np.random.NORMAL 
```


```python
#Additionally
```


```python
var1 = np.random.normal(5,.5, 100)
```


```python
var2 = np.random.normal(10, 1, 100)
```


```python
var3 = var1+var2
```


```python
mean = np.mean(var3)
```


```python
sd = np.std(var3)
```


```python
plt.hist(var3)
plt.axvline(x=mean, color='black')
plt.axvline(x=mean+sd, color='red')
plt.axvline(x=mean-sd, color='red')
plt.show()
```


![png](output_39_0.png)



```python
#Random seed will generate various results; results skew slightly in this normal distribution. 
```

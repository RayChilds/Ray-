

```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statistics 
%matplotlib inline
spt = pd.read_csv('/Users/raychilds/Downloads/spotify.csv')
```


```python
x = spt['tempo']
plt.title('Tempo in Top 10 Songs from Spotify 2017')
plt.ylabel('Beats Per Minute')
plt.boxplot(x)
plt.show()
```


![png](output_1_0.png)


### The median Tempo as measured in beats per minute in the top ten songs of Spotify in 2017 is 110. 
### The range of the Tempos as measured in beats per minute in the top ten songs of Spotify in 2017 is 80 to 190.
### The majority of the the Tempos as measured by beats per minute in the top ten songs of Spotify in 2017 range from 130 to 190.


```python
spt.hist('tempo', bins=40, normed=True)
plt.xlabel('Beats Per Minute (BPM)')
plt.title('Tempo in the top 100 (Spotify 2017)')
plt.show()
```


![png](output_3_0.png)


### About 50% of tempo rates for all 100 songs on the top chart hit 100 - 120 beats per minute, with outliers hitting 80 BPM and 180 BPM, respectively. About 80% of the songs have tempos higher than 100 beats per minute.  


```python
plt.figure(figsize=(10, 5))

spt.loc[lambda df: spt['tempo'] > 120, :].plot()
plt.ylabel('Values')
plt.title('Energy Levels in Electronic Music')

plt.figure(figsize=(10,5))
spt.loc[lambda df: spt['tempo'] < 120, :].plot()
plt.ylabel('Values')
plt.title('Energy Levels in Pop Music')
```




    Text(0.5,1,'Energy Levels in Pop Music')




    <matplotlib.figure.Figure at 0x10a3e5668>



![png](output_5_2.png)



    <matplotlib.figure.Figure at 0x10a422c18>



![png](output_5_4.png)


### Energy levels are much higher in club music, in compared to the rest of the top streamed music, that is, standard pop music, respectively. 


```python
spt['danceability'].plot()
plt.title('Danceability in Top 100 Streamed Songs')
plt.xlabel('Top 100 Songs')
plt.ylabel('Danceability Levels')
```




    Text(0,0.5,'Danceability Levels')




![png](output_7_1.png)


### Danceability ranges are much more varied than tempo by itself. Part of this is accounted for the complexity of danceability (a combination of three musical attributes). But for the most part, danceability levels stay above .5, with a few outliers never dropping below .3. This isn't too surprising, as we can assume pop algorithms require at least some danceability, for the song to be a hit at public place, as in, music that gives people energy and doesn't use too many minor chords that generally make people more thoughtful than anything else. It doesn't seem likely the best marketing tactic to play music in stores that increases thoughtfulness, as opposed to feeling confident and shopping-ready. 
